# projet_h2021_g16

Projet de fin de session H2021 pour le cours 420-G16-RO 