USE vente_billets ;

DELETE FROM billet ;
DROP table billet ;

DELETE FROM acheteur ;
DROP table acheteur ;

DELETE FROM utilisateur ;
DROP table utilisateur ;

DELETE FROM voyage ;
DROP table voyage ; 

DELETE FROM infos_voyage ;
DROP table infos_voyage ; 

DROP DATABASE vente_billets ; 