<?php	
	/* Description : paramettres d'accès à la BD
	 * Date        : 9 avril 2021
     * Auteur      : Pierre Coutu
	*/
	interface ConfigBD
	{	
		const BD_HOTE = "localhost";
		const BD_UTILISATEUR = "root";
		const BD_MOT_PASSE = "root";
		// ********************* À remplacer par le nouveau nom de BD *******************
		const BD_NOM = "vente_billets";    
	}
?>