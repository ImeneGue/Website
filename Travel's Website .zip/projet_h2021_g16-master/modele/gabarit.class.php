﻿<?php
// *******************************************
// Projet H2021
// Classe      : ZZZZ
// Description :
// Auteurs     : Pierre Coutu
// *******************************************

// ****** INLCUSIONS *******
// si la constante n'existe pas, on la crée
if (defined("DOSSIER_BASE_INCLUDE") == false) {
	$chemin=(substr($_SERVER['DOCUMENT_ROOT'],-1)=="/")?$_SERVER['DOCUMENT_ROOT']:$_SERVER['DOCUMENT_ROOT']."/";
	define("DOSSIER_BASE_INCLUDE", $chemin."projet_h2021_g16/");
}
//include_once(DOSSIER_BASE_INCLUDE."modele/ZZZZ.class.php"); 

// Classe représentant une ZZZZ (à modifier ...)
class ZZZZ {
	// Attributs
	
	// Constructeur __construct
	
	// Accesseurs et mutateurs

	// Autres méthodes 
	
	// __toString

}
?>